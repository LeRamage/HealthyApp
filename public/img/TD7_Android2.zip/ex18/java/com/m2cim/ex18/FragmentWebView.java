package com.m2cim.ex18;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class FragmentWebView extends Fragment {
    private View _vue;
    private String titre;
    private MainActivity _act;
    WebView _web;

    public FragmentWebView() {}

    public FragmentWebView(String s) {
        titre = s;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        _act = (MainActivity)getActivity(); // Stocke une référence sur l'activité qui contient le fragment
        _vue = inflater.inflate(R.layout.fragment_webview, container, false); // Création de la vue par expansion

        _web = (WebView)_vue.findViewById(R.id.frg_web); // Récupération de la vue web déclarée dans le XML

        WebSettings prop = _web.getSettings(); // Réglages des paramètres
        prop.setPluginState(WebSettings.PluginState.ON);   // Activation des plug-ins
        prop.setSavePassword(false);           // Activation de la mémorisation des mots de passe
        prop.setSaveFormData(false);           // Activation de la mémorisation des contenus de champ
        prop.setJavaScriptEnabled(true);       // Activation de JS

        _web.loadUrl("http://www.google.fr");  // Chargement de la page dans la vue web (N.B.: ignorer l'exception lancée : bug Android)

        return _vue;
    }
}