package com.m2cim.ex18;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

// Classe représentant un fragment permettant la lecture d'un PDF
//
public class FragmentPDF extends Fragment {
    private View _vue;
    private String titre;
    private MainActivity _act;

    private static final int CODE_LECTURE_PDF = 1;

    public FragmentPDF() {}

    public FragmentPDF(String s) {
        titre = s;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        _act = (MainActivity)getActivity(); // Stocke une référence sur l'activité qui contient le fragment
        _vue = inflater.inflate(R.layout.fragment_pdf, container, false); // Création de la vue par expansion
        ((TextView)_vue.findViewById(R.id.frg_titre)).setText(titre); // Injection du titre du fragment dans le layout

        // Copie du fichier depuis les assets vers le répertoire de l'application
        //
        try {
            FileOutputStream fos = _act.openFileOutput("test.pdf", Context.MODE_PRIVATE); // Ou MODE_WORLD_READABLE : alternative au fournisseur de contenu, mais déconseillé par les guidelines Android
            _act.copieFic(_act.getAssets().open("test.pdf"), fos);
        } catch (Exception e) { e.printStackTrace(); }

        // Pose de l'écouteur pour déclencher la lecture PDF au clic du bouton
        //
        _vue.findViewById(R.id.frg_bouton).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int err = lecturePDF("test.pdf");
                if (err != 0) Toast.makeText(_act, err, Toast.LENGTH_SHORT).show(); // Appel à la version de Toast.makeText() qui prend un identifiant de ressource chaîne en 2nd paramètre
            }
        });

        return _vue; // Retourne la vue
    }

    private int lecturePDF(String nomFic) {
        // Vérification 1 : y a-t-il une application adaptée installée sur l'appareil ?
        //
        Intent test = new Intent();
        test.setAction(Intent.ACTION_VIEW);
        test.setType("application/pdf");
        // Le package manager est le gestionnaire d'applications
        // Ici, il nous permet de savoir si une application installée sur l'appareil pourra répondre à notre intent
        //
        if (_act.getPackageManager().queryIntentActivities(test, PackageManager.MATCH_DEFAULT_ONLY).size() == 0) return R.string.frg2_err_pdfrdr;

        // Vérification 2 : le fichier existe-t-il ?
        //
        File fic = new File(_act.getFilesDir() + "/" + nomFic); // getFilesDir() retourne le chemin absolu du répertoire des fichiers de l'application (ici : "/data/data/com.m2cim.ex18/files")
        if (!fic.isFile()) return R.string.frg2_err_fic;

        // Création de l'intent
        //
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse("content://com.m2cim.ex18/" + nomFic), "application/pdf"); // Accès au content provider (qui doit bien sûr exister et être déclaré dans le manifeste)

        startActivityForResult(intent, CODE_LECTURE_PDF); // Appel de l'application avec gestion du retour (Si la gestion du retour n'est pas nécessaire, on utilisera startActivity(intent)

        return 0;
    }

    @Override
    public void onActivityResult (int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_CANCELED && requestCode == CODE_LECTURE_PDF) { // Si l'application termine normalement et qu'il s'agit bien de l'application de lecture de PDF (ici, pas d'ambiguïté, mais il pourrait y en avoir dans d'autres cas)
            Toast.makeText(_act, R.string.frg2_lecture_ok, Toast.LENGTH_SHORT).show();
        }
    }
}
