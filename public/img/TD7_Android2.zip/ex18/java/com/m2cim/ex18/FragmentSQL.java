package com.m2cim.ex18;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class FragmentSQL extends Fragment {
    private View _vue;
    private String titre;
    private MainActivity _act;

    private static final int CODE_LECTURE_PDF = 1;

    public FragmentSQL() {}

    public FragmentSQL(String s) {
        titre = s;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        _act = (MainActivity)getActivity(); // Stocke une référence sur l'activité qui contient le fragment
        _vue = inflater.inflate(R.layout.fragment_sql, container, false); // Création de la vue par expansion
        ((TextView)_vue.findViewById(R.id.frg_titre)).setText(titre); // Injection du titre du fragment dans le layout

        // Création de la base de données SQLite (N.B.: contenue dans un fichier unique, dans le répertoire de l'application)
        //
        File fic = new File(_act.getFilesDir() + "/sqlite.bdd");
        SQLiteDatabase bdd = SQLiteDatabase.openOrCreateDatabase(fic, null);

        // Création de table
        //
        bdd.execSQL("CREATE TABLE IF NOT EXISTS clients (" + // execSQL permet d'exécuter toute requête SQL *autre que* SELECT
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +   // 4 types de données seulement : INTEGER, REAL, TEXT et BLOB
                "nom TEXT," +                                // Noter le nom de la clé primaire (_id) : Android l'utilise automatiquement à plusieurs occasions (par ex. pour les adaptateurs ListView et GridView), donc à respecter
                "prenom TEXT," +                             // Noter aussi la différence avec MySQL : AUTOINCREMENT sans underscore "_" et *après* "PRIMARY KEY"
                "cp TEXT," +
                "ville TEXT," +
                "email TEXT" +
                ")");

        // Insertion
        //
        bdd.execSQL("INSERT INTO clients (nom, prenom, cp, ville, email) VALUES ('Dupont', 'Jean', '69003', 'Lyon', 'jdupont@gmail.com')");

        // Insertion, manière Android
        //
        ContentValues valeurs = new ContentValues();
        valeurs.put("nom", "Durand");
        valeurs.put("prenom", "Marie");
        valeurs.put("cp", "75001");
        valeurs.put("ville", "Paris");
        valeurs.put("email", "jdurand@gmail.com");
        bdd.insert("clients", null, valeurs);

        // Mise à jour v1
        //
        bdd.execSQL("UPDATE clients SET cp = '75002' WHERE _id = ?", new String[] {"2"}); // Ou bien avec un seul paramètre, et valeur en dur dans ce paramètre

        // Mise à jour v2
        //
        Cursor c2 = bdd.rawQuery("UPDATE clients SET cp = '75003' WHERE _id = ?", new String[] {"2"}); // rawQuery est plutôt adaptée aux requêtes SELECT, mais permet d'exécuter toute requête SQL ; rawQuery renvoie un curseur (classe Cursor)
        c2.moveToFirst(); c2.close(); // N.B.: ces 2 instructions sont obligatoires pour que l'update fonctionne

        // Mise à jour, manière Android
        //
        valeurs = new ContentValues();
        valeurs.put("cp", "75004");
        bdd.update("clients", valeurs, "_id = ?", new String[] {"2"});

        // Récupération
        //
        Cursor c = bdd.rawQuery("SELECT * FROM clients WHERE _id = ?", new String[] {"2"});
        c.moveToFirst();
        while (!c.isAfterLast()) {
            Toast.makeText(_act, c.getString(0) + ":" + c.getString(1) + ":" + c.getString(2) + ":" + c.getString(3), Toast.LENGTH_SHORT).show();
            c.moveToNext();
        }

        // Récupération, manière Android
        //
        c = bdd.query("clients", new String[] {"nom", "prenom", "cp", "ville", "email"}, "nom LIKE ?", new String[] {"Du%"}, null, null, null); // Les 3 derniers paramètres sont des tableaux de String optionnels utilisés pour spécifier respectivement des clauses "GROUP BY", "HAVING" et "ORDER BY"
        c.moveToFirst();
        while (!c.isAfterLast()) {
            Toast.makeText(_act, c.getString(0) + ":" + c.getString(1) + ":" + c.getString(2) + ":" + c.getString(3), Toast.LENGTH_SHORT).show();
            c.moveToNext();
        }

        c.close();
        bdd.close();

        return _vue;
    }
}
