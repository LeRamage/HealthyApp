package com.m2cim.ex17;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

// Classe représentant un fragment permettant la prise de photos
//
public class FragmentPhoto extends Fragment {
    private View _vue;
    private String titre;
    private MainActivity _act;
    private File _fic;

    private static final int CODE_PHOTO = 1;

    public FragmentPhoto() {}

    public FragmentPhoto(String s) {
        titre = s;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        _act = (MainActivity)getActivity(); // Stocke une référence sur l'activité qui contient le fragment
        _vue = inflater.inflate(R.layout.fragment_photo, container, false); // Création de la vue par expansion
        ((TextView)_vue.findViewById(R.id.frg_titre)).setText(titre); // Injection du titre du fragment dans le layout

        // Pose de l'écouteur pour déclencher la prise de photo au clic du bouton
        //
        ((Button)_vue.findViewById(R.id.frg_bouton)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                _fic = null;
                try {
                    _fic = new File(Environment.getExternalStorageDirectory().getAbsoluteFile(), "photo.jpg"); // Création du fichier temporaire qui stockera la photo
                } catch (Exception e) { e.printStackTrace(); }
                if (_fic != null) {
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(_fic)); // Ajoute à l'intent le nom du fichier qui stockera la photo
                    startActivityForResult(intent, CODE_PHOTO); // Démarrage de l'activité tierce
                } else Log.e("Ex11", "Bug création du fichier photo");
            }
        });

        return _vue; // Retourne la vue (obligatoire)
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_CANCELED) {
            if (requestCode == CODE_PHOTO) {
                try { // On déplace la photo de la carte SD vers le répertoire de l'application (pour un traitement ultérieur par exemple)
                    _act.copieFic(new FileInputStream(_fic), new FileOutputStream(new File(_act.getFilesDir(), "photo_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".jpg")));
                    _fic.delete();
                } catch (Exception e) { e.printStackTrace(); }
            }
        }
    }
}
