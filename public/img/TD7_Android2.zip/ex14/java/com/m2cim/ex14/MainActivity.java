package com.m2cim.ex14;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

// Exercice 14 : Navigation entre les fragments par une barre de boutons
//
public class MainActivity extends AppCompatActivity {
    private FragmentVide[] _tFrg;
    private Button[] _tBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Ex14:ACT", "*** onCreate ******************************************************");

        String[] tSections = getResources().getStringArray(R.array.tab_sections); // On récupère les noms de section depuis les ressources res/values/strings.xml
        ViewGroup nvg = (ViewGroup)findViewById(R.id.navigation);
        _tFrg = new FragmentVide[tSections.length]; // On crée le tableau de fragments
        _tBtn = new Button[tSections.length]; // et le tableau de boutons de navigation
        for (int i = 0; i < tSections.length; i++) {
            _tFrg[i] = new FragmentVide(tSections[i]); // On crée les fragments eux-même
            _tBtn[i] = new Button(this); // et les boutons de la barre de navigation de l'activité principale
            _tBtn[i].setText("Frg " + (i + 1)); // Intitulé du bouton
            _tBtn[i].setId(i); // On utilise ce champ pour pouvoir récupérer le numéro de bouton (et donc de fragment) à partir de la vue
            _tBtn[i].setOnClickListener(new OnClickListener() { // Pose de l'écouteur pour changer de fragment au clic sur le bouton (N.B.: utilisation ici d'une classe anonyme)
                @Override
                public void onClick(View v) {
                    int numFragment = v.getId(); // On récupère le numéro de bouton (et donc le numéro du fragment associé)
                    getSupportFragmentManager().beginTransaction().replace(R.id.conteneur, _tFrg[numFragment]).commit(); // On charge le fragment correspondant au bouton cliqué
                }
            });
            nvg.addView(_tBtn[i]);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.conteneur, _tFrg[0]).commit(); // On charge le premier fragment
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Ex14:ACT", "*** onStart ******************************************************");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Ex14:ACT", "*** onRestart ******************************************************");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Ex14:ACT", "*** onResume ******************************************************");
    }

    @Override
    protected void onPause() {
        Log.d("Ex14:ACT", "*** onPause ******************************************************");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d("Ex14:ACT", "*** onStop ******************************************************");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d("Ex14:ACT", "*** onDestroy ******************************************************");
        super.onDestroy();
    }
}
