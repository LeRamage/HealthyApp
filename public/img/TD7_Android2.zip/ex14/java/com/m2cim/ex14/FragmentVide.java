package com.m2cim.ex14;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

// Classe représentant un fragment, c-à-d un écran de l'activité
//
public class FragmentVide extends Fragment {
    private View _vue;
    private String titre;

    public FragmentVide() {
        Log.d("Ex14:FRG1", "*** constructeur1 **************************************************");
    }

    public FragmentVide(String s) {
        Log.d("Ex14:FRG1", "*** constructeur2 **************************************************");
        titre = s;
    }

    @Override
    public void onAttach(Context c) {
        super.onAttach(c);
        Log.d("Ex14:FRG1", "*** onAttach ******************************************************");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        _vue = inflater.inflate(R.layout.fragment_vide, container, false); // Création de la vue par expansion
        ((TextView)_vue.findViewById(R.id.frg_titre)).setText(titre); // Injection du titre du fragment dans le layout
        Log.d("Ex14:FRG1", "*** onCreateView **************************************************");
        return _vue; // Retourne la vue (obligatoire)
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Ex14:FRG1", "*** onCreate ******************************************************");
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.d("Ex14:FRG1", "*** onActivityCreated *********************************************");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d("Ex14:FRG1", "*** onStart *******************************************************");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("Ex14:FRG1", "*** onResume ******************************************************");
    }

    @Override
    public void onPause() {
        Log.d("Ex14:FRG1", "*** onPause *******************************************************");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.d("Ex14:FRG1", "*** onStop ********************************************************");
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        Log.d("Ex14:FRG1", "*** onDestroyView *************************************************");
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        Log.d("Ex14:FRG1", "*** onDestroy *****************************************************");
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        Log.d("Ex14:FRG1", "*** onDetach ******************************************************");
        super.onDetach();
    }
}
