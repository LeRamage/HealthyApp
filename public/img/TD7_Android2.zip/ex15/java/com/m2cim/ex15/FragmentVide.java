package com.m2cim.ex15;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

// Classe représentant un fragment, c-à-d un écran de l'activité
//
public class FragmentVide extends Fragment {
    private View _vue;
    private String titre;

    public FragmentVide() {}

    public FragmentVide(String s) {
        titre = s;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _vue = inflater.inflate(R.layout.fragment_vide, container, false); // Création de la vue par expansion
        ((TextView)_vue.findViewById(R.id.frg_titre)).setText(titre); // Injection du titre du fragment dans le layout
        return _vue; // Retourne la vue (obligatoire)
    }

}
