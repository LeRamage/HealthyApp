package com.m2cim.ex15;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import java.io.InputStream;
import java.io.OutputStream;

// Exercice 15 : Réécriture de Fragment1 pour prendre des photos
//
public class MainActivity extends AppCompatActivity {
    private Fragment[] _tFrg;
    private Button[] _tBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] tSections = getResources().getStringArray(R.array.tab_sections); // On récupère les noms de section depuis les ressources resources/strings.xml
        ViewGroup nvg = (ViewGroup)findViewById(R.id.navigation);
        _tFrg = new Fragment[tSections.length]; // On crée le tableau de fragments
        // Fragment photo
        //
        _tFrg[0] = new FragmentPhoto(tSections[0]);
        // Fragments vides
        //
        for (int i = 1; i < tSections.length; i++) _tFrg[i] = new FragmentVide(tSections[i]);
        // Boutons
        //
        _tBtn = new Button[tSections.length]; // Création du tableau de boutons de navigation
        for (int i = 0; i < tSections.length; i++) {
            _tBtn[i] = new Button(this); // et les boutons de la barre de navigation de l'activité principale
            _tBtn[i].setText("Frg " + (i + 1)); // Intitulé du bouton
            _tBtn[i].setId(i); // On utilise ce champ pour pouvoir récupérer le numéro de bouton (et donc de fragment) à partir de la vue
            _tBtn[i].setOnClickListener(new OnClickListener() { // Pose de l'écouteur pour changer de fragment au clic sur le bouton
                @Override
                public void onClick(View v) {
                    int numFragment = v.getId(); // On récupère le numéro de bouton (et donc le numéro du fragment associé)
                    getSupportFragmentManager().beginTransaction().replace(R.id.conteneur, _tFrg[numFragment]).commit(); // On charge le fragment correspondant au bouton cliqué
                }
            });
            nvg.addView(_tBtn[i]);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.conteneur, _tFrg[0]).commit(); // On charge le premier fragment
    }

    // Méthode utilitaire de copie de fichier
    //
    public boolean copieFic(InputStream src, OutputStream dest) throws Exception {
        boolean ret = false;
        byte[] buffer = new byte[1024];
        int length;
        while ((length = src.read(buffer)) > 0) dest.write(buffer, 0, length);
        dest.flush();
        dest.close();
        src.close();
        ret = true;
        return ret;
    }
}
