package com.m2cim.ex16;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

public class PDFProvider extends ContentProvider { // Fournisseur de contenu pour les fichiers PDF
    @Override
    public String getType(Uri uri) {
        return("application/pdf");
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException { // Pour un contenu sous forme de fichier, il suffit de redéfinir cette méthode
        File f = new File(getContext().getFilesDir(), uri.getPath()); // Crée le fichier demandé (présent dans le répertoire files de l'application)
        if (f.exists()) return (ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)); // Retourne le fichier sous forme d'un objet ParcelFileDescriptor qui sera utilisé par le consommateur de contenu
        else throw new FileNotFoundException(uri.getPath());
    }

    // Ces méthodes sont à redéfinir uniquement pour les fournisseurs de données structurées (type BDD)
    //
    @Override
    public boolean onCreate() { return(true); }

    @Override
    public Cursor query(Uri url, String[] projection, String selection, String[] selectionArgs, String sort) { return null; }

    @Override
    public Uri insert(Uri uri, ContentValues initialValues) { return null; }

    @Override
    public int update(Uri uri, ContentValues values, String where, String[] whereArgs) { return 0; }

    @Override
    public int delete(Uri uri, String where, String[] whereArgs) { return 0; }
}
